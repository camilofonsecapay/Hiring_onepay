# Hiring OnePay

Sitio de vacantes de OnePay. HTML estático, sin build ni dependencias.
Vercel lo publica tal cual: `/` es el índice y cada carpeta es una vacante.

## Estructura

```
index.html             Página principal con la lista de vacantes
style.css              Sistema de diseño completo
app.js                 Nav, footer, logo, isotipo y animación de aparición
robots.txt
aibdr/index.html       -> /aibdr
enterprise/index.html  -> /enterprise
growth/index.html      -> /growth
```

## Cómo abrir una vacante nueva

1. Copia la carpeta de la vacante más parecida y renómbrala. El nombre de la
   carpeta es la URL: `finance/` se publica en `/finance`.
2. Dentro del `index.html` nuevo edita, en este orden:
   - `<title>`, `og:title` y `og:description`. Son las que LinkedIn lee para
     armar la previsualización del link, así que tienen que ser del rol.
   - El bloque `.jobhero`: migaja, chip de área, `<h1>`, `.jobmeta` y `.jobhook`.
   - El `<article class="jd">` con la descripción.
   - El `href` del formulario de Tally en los dos botones de aplicar.
   - Las tarjetas de "Otras vacantes abiertas" al final.
3. En el `index.html` de la raíz agrega una fila `<a class="rowlink" href="/tu-vacante">`
   copiando una existente y actualiza la numeración.
4. Commit. Vercel publica solo.

## Cómo cerrar una vacante

Borra su carpeta y su fila en `index.html`. Si no queda ninguna, cambia el
titular de la sección por "Hoy no tenemos búsquedas abiertas".

## Formularios

Cada vacante apunta a un formulario de Tally distinto. Las respuestas caen en la
base de Notion "Candidatos".

| Vacante               | Formulario                |
| --------------------- | ------------------------- |
| AI BDR                | https://tally.so/r/44lNGY |
| Enterprise AE         | https://tally.so/r/7R7JX0 |
| Growth Marketer       | https://tally.so/r/VLWZql |
| Aplicación espontánea | https://tally.so/r/QKNxMG |

## Nota sobre LinkedIn

El crawler de LinkedIn no ejecuta JavaScript. Por eso el contenido de cada
vacante está escrito directamente en el HTML y las etiquetas `og:` viven en el
`<head>`. Si alguna vez mueves ese contenido a JavaScript, la previsualización
del link deja de funcionar.
